# -*- coding: utf-8 -*-
"""
Created on Thu Mar 17 07:45:13 2016

@author: Kami
"""

import math
from math import sqrt
import numpy as np
import pandas as pa
import matplotlib.pyplot as plt
import statsmodels.api as sm
import sklearn
from sklearn import linear_model
from sklearn.preprocessing import normalize
from sklearn.cross_validation import KFold
from sklearn.ensemble import RandomForestRegressor
from sklearn.feature_selection import f_regression
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import PolynomialFeatures
import datetime, time

import problem3_predict as p3_p

def get_polynomial_regressor(tag,period):
    hashtag = ['gohawks', 'gopatriots', 'nfl', 'patriots', 'sb49', 'superbowl']
    tag_start=tag
    tag_num=1
    for i in range(tag_start,tag_start+tag_num):
        filename = 'problem3_data_#%s' %hashtag[i]
        data_tmp = np.loadtxt(filename)
        if(i == tag_start):
            network = data_tmp
        else:
            network = np.concatenate((network,data_tmp))
    
#    data = network[0:len(network)-1,0:3]
#    target =network[1:,0]
#    data=np.nan_to_num(data)
#    data = StandardScaler().fit_transform(data)
#    linear_Regression(data, target, network)
    start_date = datetime.datetime(2015,01,16, 12,0,0)
    end_date = datetime.datetime(2015,02,07, 03,0,0)
    superbowl_start=datetime.datetime(2015,02,01, 8,0,0)
    superbowl_end=datetime.datetime(2015,02,01, 20,0,0)
    mintime = int(time.mktime(start_date.timetuple()))
    maxtime = int(time.mktime(end_date.timetuple()))
    starttime = int(time.mktime(superbowl_start.timetuple()))
    endtime = int(time.mktime(superbowl_end.timetuple()))
    index1=(starttime-mintime)/3600
    index2=(endtime-mintime)/3600
    if(period==1):
        network_period = network[0:index1,0:]
    elif(period==2):
        network_period = network[index1:index2,0:]
    elif(period==3):
        network_period = network[index2+1:-1,0:]
    else:
        network_period = network[0:len(network)-1,0:]
    target = network_period[1:,0]
    data = np.concatenate((network_period[0:len(network_period)-1,0:1],network_period[0:len(network_period)-1,4:5],network_period[0:len(network_period)-1,6:7],network_period[0:len(network_period)-1,8:9]),axis=1)
    data=np.nan_to_num(data)
    poly = PolynomialFeatures(degree=2)
    data_poly=poly.fit_transform(data)
    lr=linear_model.Lasso (alpha = 1)
    lr.fit(data_poly, target)        
    return lr,data_poly,target        

def get_linear_regressor(tag,period):
    hashtag = ['gohawks', 'gopatriots', 'nfl', 'patriots', 'sb49', 'superbowl']
    tag_start=tag
    tag_num=1
    for i in range(tag_start,tag_start+tag_num):
        filename = 'problem2_data_#%s' %hashtag[i]
        data_tmp = np.loadtxt(filename)
        if(i == tag_start):
            network = data_tmp
        else:
            network = np.concatenate((network,data_tmp))
    
#    data = network[0:len(network)-1,0:3]
#    target =network[1:,0]
#    data=np.nan_to_num(data)
#    data = StandardScaler().fit_transform(data)
#    linear_Regression(data, target, network)
    start_date = datetime.datetime(2015,01,16, 12,0,0)
    end_date = datetime.datetime(2015,02,07, 03,0,0)
    superbowl_start=datetime.datetime(2015,02,01, 8,0,0)
    superbowl_end=datetime.datetime(2015,02,01, 20,0,0)
    mintime = int(time.mktime(start_date.timetuple()))
    maxtime = int(time.mktime(end_date.timetuple()))
    starttime = int(time.mktime(superbowl_start.timetuple()))
    endtime = int(time.mktime(superbowl_end.timetuple()))
    index1=(starttime-mintime)/3600
    index2=(endtime-mintime)/3600
    if(period==1):
        network_period = network[0:index1,0:]
        
    elif(period==2):
        network_period = network[index1:index2,0:]
    elif(period==3):
        network_period = network[index2+1:-1,0:]
    else:
        network_period = network[0:len(network)-1,0:]
    data = np.concatenate((network_period[0:len(network_period)-1,0:1],network_period[0:len(network_period)-1,4:5],network_period[0:len(network_period)-1,6:7],network_period[0:len(network_period)-1,8:9]),axis=1)
    target =network_period[1:,0]    
    data = np.nan_to_num(data)
    lr = linear_model.LinearRegression(normalize = True)
    lr.fit(data,target)        
    return lr,data,target    

def linear_Regression(tag,period):
    lr,data,target = get_linear_regressor(tag,period)
#    print lr.coef_
#    lr=
#    lr.fit(data, target)
#    F, pval = f_regression(data, lr.predict(data))
    lr_predict=lr.predict(data)
#    rmse_linear = sqrt(np.mean((lr_predict - target) ** 2))
    kf = KFold(len(target), n_folds=10, shuffle=True, random_state=None)
    ABS_LINEAR = []
    for train_index, test_index in kf:
        data_train, data_test = data[train_index], data[test_index]
        target_train, target_test = target[train_index], target[test_index]
        lr.fit(data_train, target_train)
        lr_predict=lr.predict(data_test)
#        rfr = rfr.fit(data_train, target_train)
        abs_linear = np.mean(abs(lr.predict(data_test) - target_test))
        ABS_LINEAR.append(abs_linear)
    print("average prediction error of cross validation is {0:f}".format(np.mean(ABS_LINEAR)))
    return ABS_LINEAR,lr_predict

def polynomial_Regression(tag,period):
    lr,data,target = get_polynomial_regressor(tag,period)
#    print lr.coef_
#    lr=
#    lr.fit(data, target)
#    F, pval = f_regression(data, lr.predict(data))
    lr_predict=lr.predict(data)
#    rmse_linear = sqrt(np.mean((lr_predict - target) ** 2))
    kf = KFold(len(target), n_folds=10, shuffle=True, random_state=None)
    ABS_POLY = []
    for train_index, test_index in kf:
        data_train, data_test = data[train_index], data[test_index]
        target_train, target_test = target[train_index], target[test_index]
        lr.fit(data_train, target_train)
        lr_predict=lr.predict(data_test)
#        rfr = rfr.fit(data_train, target_train)
        abs_poly = np.mean(abs(lr.predict(data_test) - target_test))
        ABS_POLY.append(abs_poly)
    print("average prediction error of cross validation is {0:f}".format(np.mean(ABS_POLY)))
    return ABS_POLY,lr_predict
    
def main():
#    hashtag = ['gohawks', 'gopatriots', 'nfl', 'patriots', 'sb49', 'superbowl']
    tag_start=5
    tag_num=6
#    for i in range(tag_start,tag_start+tag_num):
#        filename = 'problem2_data_#%s' %hashtag[i]
#        data_tmp = np.loadtxt(filename)
#        if(i == tag_start):
#            network = data_tmp
#        else:
#            network = np.concatenate((network,data_tmp))
#    
#    data = network[0:len(network)-1,0:3]
#    target =network[1:,0]
#    data=np.nan_to_num(data)
#    data = StandardScaler().fit_transform(data)
#    linear_Regression(data, target, network)
#    start_date = datetime.datetime(2015,01,16, 12,0,0)
#    end_date = datetime.datetime(2015,02,07, 03,0,0)
#    superbowl_start=datetime.datetime(2015,02,01, 8,0,0)
#    superbowl_end=datetime.datetime(2015,02,01, 20,0,0)
#    mintime = int(time.mktime(start_date.timetuple()))
#    maxtime = int(time.mktime(end_date.timetuple()))
#    starttime = int(time.mktime(superbowl_start.timetuple()))
#    endtime = int(time.mktime(superbowl_end.timetuple()))
#    index1=(starttime-mintime)/3600
#    index2=(endtime-mintime)/3600
#    
#    
#    data = network[0:index1,:]
#    target =network[1:index1+1,0]
#    data=np.nan_to_num(data)
##    data = StandardScaler().fit_transform(data)
#    linear_Regression(data, target, network)
##    ABS_POLY,RMSE_poly,ploy_predict=p3_p.polynomial(data,target,network,2)
##    print(["RMSE_poly",np.mean(RMSE_poly)])  
#    
#    data = network[index1:index2,:]
#    target =network[index1+1:index2+1,0]
#    data=np.nan_to_num(data)
#    data = StandardScaler().fit_transform(data)
    linear_Regression(tag_start,1)
    linear_Regression(tag_start,2)
    linear_Regression(tag_start,3)
#    ABS_POLY,RMSE_poly,ploy_predict=p3_p.polynomial(2,1)
#    print(["RMSE_poly",np.mean(RMSE_poly)])
#    print(["ABS_poly",np.mean(ABS_POLY)])
    polynomial_Regression(tag_start,1)
    polynomial_Regression(tag_start,2)
    polynomial_Regression(tag_start,3)
    
#    for tag in range(6):
#        linear_Regression(tag,0)
#        polynomial_Regression(tag,0)

#    data = network[index2+1:-1,:]
#    target = network[index2+2:,0]
#    data=np.nan_to_num(data)
#    data = StandardScaler().fit_transform(data)
#    linear_Regression(data, target, network)
    
    
    
    

if __name__ == "__main__":
    main()
        