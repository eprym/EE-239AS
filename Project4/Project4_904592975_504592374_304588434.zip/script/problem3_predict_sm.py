# -*- coding: utf-8 -*-
"""
Created on Fri Mar 18 00:17:41 2016

@author: Kami
"""
#import TweetStats		#for startTime
from sklearn.cross_validation import KFold
import statsmodels.formula.api as smf
import numpy as np
from math import sqrt
from scipy import stats


hashtag = ['gohawks', 'gopatriots', 'nfl', 'patriots', 'sb49', 'superbowl']
tag_start=2
tag_num=1
for i in range(tag_start,tag_start+tag_num):
    filename = 'problem3_data_#%s' %hashtag[i]
    data_tmp = np.loadtxt(filename)
    if(i == tag_start):
        network = data_tmp
    else:
        network = np.concatenate((network,data_tmp))

data = network[0:len(network)-1,10:18]

target =network[1:,0]
data=np.nan_to_num(data)

m=smf.OLS(target[0:-1],data[0:-1])
print m.fit().summary()
m_predict=m.predict(m.fit().params,data[0:-1])

kf = KFold(len(target), n_folds=10, shuffle=True, random_state=None)
RMSE_LINEAR = []
P_VALUE=[]
ABS_LINEAR=[]
for train_index, test_index in kf:
    data_train, data_test = data[train_index], data[test_index]
    target_train, target_test = target[train_index], target[test_index]
    m=smf.OLS(target_train,data_train)
    m.fit()
#    print m.fit().summary()
    
    m_predict=m.predict(m.fit().params,data_test)
#        rfr = rfr.fit(data_train, target_train)
    rmse_linear = sqrt(np.mean((m_predict - target_test) ** 2))
    RMSE_LINEAR.append(rmse_linear)
    abs_linear = np.mean(abs(m_predict - target_test))
    ABS_LINEAR.append(abs_linear)
    t,p_value=stats.ttest_ind(m_predict,target_test)
    P_VALUE.append(p_value)
    
print(np.mean(RMSE_LINEAR))
print(np.mean(ABS_LINEAR))
print(np.mean(P_VALUE))