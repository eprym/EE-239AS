# -*- coding: utf-8 -*-
"""
Created on Wed Mar  9 13:07:37 2016

@author: YuLiqiang
"""

import math
from math import sqrt
import numpy as np
import pandas as pa
import matplotlib.pyplot as plt
import statsmodels.api as sm
import sklearn
from sklearn import linear_model
from sklearn.preprocessing import normalize
from sklearn.cross_validation import KFold
from sklearn.ensemble import RandomForestRegressor
from sklearn.feature_selection import f_regression
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import PolynomialFeatures

from pybrain import *
from pybrain.datasets import SupervisedDataSet
from pybrain.tools.shortcuts import buildNetwork
from pybrain.supervised.trainers import BackpropTrainer
from pybrain.structure.modules.neuronlayer import *

from scipy import stats



# Compare the linear regression model and random forest regression model
def linear_Regression(data, target, network):
    lr = linear_model.LinearRegression(normalize = True)
#    lr=linear_model.Lasso (alpha = 100)
    lr.fit(data, target)
    F, pval = f_regression(data, lr.predict(data))
    print(pval)
    lr_predict=lr.predict(data)
#    rmse_linear = sqrt(np.mean((lr_predict - target) ** 2))
    kf = KFold(len(target), n_folds=10, shuffle=True, random_state=None)
    RMSE_LINEAR = []
    ABS_LINEAR=[]
    P_VALUE=[]
    for train_index, test_index in kf:
        data_train, data_test = data[train_index], data[test_index]
        target_train, target_test = target[train_index], target[test_index]
        lr.fit(data_train, target_train)
        
#        rfr = rfr.fit(data_train, target_train)
        rmse_linear = sqrt(np.mean((lr.predict(data_test) - target_test) ** 2))
        RMSE_LINEAR.append(rmse_linear)
        
        abs_linear = np.mean(abs(lr.predict(data_test) - target_test))
        ABS_LINEAR.append(abs_linear)        
        
        t,p_value=stats.ttest_ind(lr.predict(data_test),target_test)
        P_VALUE.append(p_value)
 
    return ABS_LINEAR,RMSE_LINEAR,lr_predict,P_VALUE
  


# Fit the data with neural network
def neural_network(data, target, network):
    DS = SupervisedDataSet(len(data[0]), 1)
    nn = buildNetwork(len(data[0]), 7, 1, bias = True)
    kf = KFold(len(target), 10, shuffle = True);
    RMSE_NN = []
    for train_index, test_index in kf:
        data_train, data_test = data[train_index], data[test_index]
        target_train, target_test = target[train_index], target[test_index]
        for d,t in zip(data_train, target_train):
            DS.addSample(d, t)
        bpTrain = BackpropTrainer(nn,DS, verbose = True)
        #bpTrain.train()
        bpTrain.trainUntilConvergence(maxEpochs = 10)
        p = []
        for d_test in data_test:
            p.append(nn.activate(d_test))
        
        rmse_nn = sqrt(np.mean((p - target_test)**2))
        RMSE_NN.append(rmse_nn)
        DS.clear()
    time = range(1,11)
    plt.figure()
    plt.plot(time, RMSE_NN)
    plt.xlabel('cross-validation time')
    plt.ylabel('RMSE')
    plt.show()
    print(np.mean(RMSE_NN))

def neural_network_converg(data, target, network):
    DS = SupervisedDataSet(len(data[0]), 1)
    nn = buildNetwork(len(data[0]), 7, 1, bias = True, hiddenclass = SigmoidLayer, outclass = LinearLayer) 
    for d, t in zip(data, target):
         DS.addSample(d,t)
    Train, Test = DS.splitWithProportion(0.9)
    #data_train = Train['input']
    data_test = Test['input']
    #target_train = Train['target']
    target_test = Test['target']
    bpTrain = BackpropTrainer(nn,Train, verbose = True)
    #bpTrain.train()
    bpTrain.trainUntilConvergence(maxEpochs = 10)
    p = []
    for d_test in data_test:
        p.append(nn.activate(d_test))
        
    rmse_nn = sqrt(np.mean((p - target_test)**2)) 
    print(rmse_nn) 
    
def polynomial(data,target,network,deg,alpha0):
    lr=linear_model.Lasso (alpha = alpha0)
##    lr = linear_model.LinearRegression(normalize = True)    
    poly = PolynomialFeatures(degree=deg)
    data_poly=poly.fit_transform(data)
#    lr.fit(data_poly,target)
#    poly_predict=lr.predict(data_poly);
#    RMSE_poly=sqrt(np.mean((lr.predict(data_poly) - target) ** 2))
#    F, pval = f_regression(data_poly, lr.predict(data_poly))
    ### cross validation
    kf = KFold(len(target), n_folds=10, shuffle=True, random_state=None)
    RMSE_POLY = []
    ABS_POLY=[]
    for train_index, test_index in kf:
        data_train, data_test = data_poly[train_index], data_poly[test_index]
        target_train, target_test = target[train_index], target[test_index]
        lr.fit(data_train, target_train)
        poly_predict=lr.predict(data_poly);
        rmse_linear = sqrt(np.mean((lr.predict(data_test) - target_test) ** 2))
        RMSE_POLY.append(rmse_linear)
        abs_poly=np.mean(abs(lr.predict(data_test)-target_test))
        ABS_POLY.append(abs_poly)
        
#    RMSE_poly=np.mean(RMSE_POLY)
    return ABS_POLY,RMSE_POLY,poly_predict
    
def main():
    hashtag = ['gohawks', 'gopatriots', 'nfl', 'patriots', 'sb49', 'superbowl']
    tag_start=2
    tag_num=1
    for i in range(tag_start,tag_start+tag_num):
        filename = 'problem3_data_#%s' %hashtag[i]
        data_tmp = np.loadtxt(filename)
        if(i == tag_start):
            network = data_tmp
        else:
            network = np.concatenate((network,data_tmp))
#    data=network[0:len(network)-1,0:]
    data = np.concatenate((network[0:len(network)-1,0:1],network[0:len(network)-1,4:5],network[0:len(network)-1,6:7],network[0:len(network)-1,8:9]),axis=1)
    
    target =network[1:,0]
    data=np.nan_to_num(data)
#    data = StandardScaler().fit_transform(data)
    
#    plt.figure()
#    plt.scatter(np.linspace(0,len(target)-1,len(target)), target, label = "# tweet VS time")
#    plt.xlabel("time")
#    plt.ylabel("# tweet")
#    plt.legend()
#    plt.show()
    
#    print(np.isnan(np.sum(data)))
#    print(np.isnan(np.sum(target)))
    
    ### linear regression using statsmodel
#    model = sm.OLS(target, data)
#    results = model.fit()
#    print(results.summary())
    ### if you want to make the data into binary format, uncomment the line below
    #data = preprocessed_1(network)
    
    ### compare the linear model with the random forest model
    ABS_LINEAR,RMSE_linear,lr_predict,P_VALUE_LR=linear_Regression(data, target, network)
    print(["RMSE_linear:",np.mean(RMSE_linear)])
    print(["ABS_linear:",np.mean(ABS_LINEAR)])
    print(stats.ttest_ind(lr_predict,target))
    print(np.mean(P_VALUE_LR))
    
    ### polynomial model
    ABS_POLY,RMSE_poly,ploy_predict=polynomial(data,target,network,2,1)
    print(["RMSE_poly:",np.mean(RMSE_poly)])
    print(["ABS_poly:",np.mean(ABS_POLY)])
    
    
    plt.figure()
    plt.scatter(lr_predict,data[:,1])
    plt.title("predictant VS total user_mention")
    plt.xlabel("total user_mention")
    plt.ylabel("predictant")
    plt.ylim(ymin=0)
    plt.xlim(xmin=0)
    plt.show()
    
    plt.figure()
    plt.scatter(lr_predict,data[:,2])
    plt.title("predictant VS total urls")
    plt.xlabel("total urls")
    plt.ylabel("predictant")
    plt.ylim(ymin=0)
    plt.xlim(xmin=0)
    plt.show()
    
    plt.figure()
    plt.scatter(lr_predict,data[:,3])
    plt.title("predictant VS total followers of the original author")
    plt.xlabel("total followers of the original author")
    plt.ylabel("predictant")
    plt.ylim(ymin=0)
    plt.xlim(xmin=0)
    plt.show()
    ### Tuning the parameters of the random forest, SLOW !!!
#    RMSE_rfr=randomforest_tuning(data, target, network)
#    print(RMSE_rfr)
    
    
    ### use the neural network model to fit the data
#    neural_network(data, target, network)

if __name__ == "__main__":
    main()